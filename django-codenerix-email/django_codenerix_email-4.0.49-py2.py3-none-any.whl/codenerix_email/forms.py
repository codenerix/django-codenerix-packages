# -*- coding: utf-8 -*-
#
# django-codenerix-email
#
# Codenerix GNU
#
# Project URL : http://www.codenerix.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any

from django.utils.translation import gettext_lazy as _
from django.conf import settings

from codenerix.forms import GenModelForm
from codenerix_email.models import (
    EmailTemplate,
    EmailMessage,
    EmailReceived,
    MODELS,
)


class EmailTemplateForm(GenModelForm):
    class Meta:
        model = EmailTemplate
        exclude: list[Any] = []

    def __groups__(self):
        return [
            (
                _("Details"),
                12,
                (
                    None,
                    3,
                    ["cid", 12],
                    ["content_subtype", 12],
                ),
                (
                    None,
                    9,
                    ["efrom", 9],
                ),
            ),
        ]

    @staticmethod
    def __groups_details__():
        return [
            (
                _("Details"),
                12,
                ["cid", 3],
                ["efrom", 9],
            )
        ]


class EmailMessageForm(GenModelForm):
    class Meta:
        model = EmailMessage
        exclude = [
            "sending",
            "log",
            "opened",
            "unsubscribe_url",
            "bounces_total",
            "bounces_soft",
            "bounces_hard",
        ]

    def __groups__(self):
        return [
            (
                _("Basics"),
                8,
                ["efrom", 6],
                ["eto", 6],
                ["subject", 12],
            ),
            (
                _("Control"),
                4,
                ["priority", 4],
                ["sent", 4],
                ["error", 4],
                ["retries", 4],
                ["content_subtype", 8],
            ),
            (
                _("Contents"),
                12,
                ["headers", 12],
                ["body", 12],
            ),
        ]

    @staticmethod
    def __groups_details__():
        return [
            (
                _("Details"),
                4,
                ["uuid", 3],
                ["created", 3],
                ["updated", 3],
                ["efrom", 3],
                ["eto", 3],
                ["subject", 3],
                ["opened", 3],
            ),
            (
                _("System"),
                4,
                ["sending", 3],
                ["sent", 3],
                ["error", 3],
                ["log", 3],
                ["content_subtype", 3],
                ["unsubscribe_url", 3],
                ["headers", 3],
            ),
            (
                _("Status"),
                4,
                ["retries", 3],
                ["priority", 3],
                ["bounces_total", 3],
                ["bounces_soft", 3],
                ["bounces_hard", 3],
            ),
            (
                _("Body"),
                12,
                ["body", 3],
            ),
        ]


class EmailReceivedForm(GenModelForm):
    class Meta:
        model = EmailReceived
        exclude = ["sending", "log"]

    # def __groups__(self):
    #     return [
    #         (
    #             _("Details"),
    #             12,
    #             ["efrom", 2],
    #             ["eto", 2],
    #             ["subject", 4],
    #             ["priority", 1],
    #             ["sent", 1],
    #             ["error", 1],
    #             ["retries", 1],
    #             ["body", 12],
    #         )
    #     ]

    @staticmethod
    def __groups_details__():
        return [
            (
                _("Details"),
                6,
                ["imap_id", 3],
                ["eid", 3],
                ["created", 3],
                ["updated", 3],
                ["efrom", 3],
                ["eto", 3],
                ["subject", 3],
                ["bounce_type", 3],
                ["bounce_reason", 3],
                ["email", 3],
            ),
            (
                _("System"),
                6,
                ["headers", None],
                ["headers_pretty", 3],
            ),
            (
                _("Body"),
                12,
                ["body_text", 12],
                ["body_html", 12],
            ),
        ]


for info in MODELS:
    field = info[0]
    model = info[1]
    for lang_code in settings.LANGUAGES_DATABASES:
        query = "from codenerix_email.models import {}Text{}\n".format(
            model, lang_code
        )
        exec(query)
        query = """
class {model}TextForm{lang}(GenModelForm):\n
    class Meta:\n
        model={model}Text{lang}\n
        exclude = []\n
    def __groups__(self):\n
        return [(_('Details'),12,"""

        if lang_code == settings.LANGUAGES_DATABASES[0]:
            query += """
                ['subject', 12, None, None, None, None, None, ["ng-change=refresh_lang_field('subject', '{model}TextForm', [{languages}])"]],
                ['body', 12, None, None, None, None, None, ["ng-blur=refresh_lang_field('body', '{model}TextForm', [{languages}])"]],
            )]\n"""  # noqa: E501
        else:
            query += """
                ['subject', 12],
                ['body', 12],
                )]\n"""
        exec(
            query.format(
                model=model,
                lang=lang_code,
                languages="'{}'".format(
                    "','".join(settings.LANGUAGES_DATABASES)
                ),
            )
        )
