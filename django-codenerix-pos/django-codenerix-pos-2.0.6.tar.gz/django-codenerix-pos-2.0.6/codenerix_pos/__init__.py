__version__ = "2.0.6"

__authors__ = [
    'Juan Miguel Taboada Godoy <juanmi@juanmitaboada.com>',
    'Juan Soler Ruiz <soleronline@gmail.com>',
]
