CDNX_POS_PERMISSIONS = {
    'operator': [
        'list_subcategory',
        'list_productfinal',
        'list_productfinaloption',
    ],
}
