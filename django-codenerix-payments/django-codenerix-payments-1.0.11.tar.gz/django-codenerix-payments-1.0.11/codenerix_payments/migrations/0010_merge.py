# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('codenerix_payments', '0009_paymentrequest_order'),
        ('codenerix_payments', '0003_auto_20160825_0838'),
    ]

    operations = [
    ]
