"""Simply turns this module in a django app"""
