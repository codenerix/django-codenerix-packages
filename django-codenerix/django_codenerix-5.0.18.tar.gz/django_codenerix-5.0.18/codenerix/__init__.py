__version__ = "5.0.18"

__authors__ = [
    "Juanmi Taboada",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
]

__all__ = ["__version__", "__authors__", "__authors_email__"]
