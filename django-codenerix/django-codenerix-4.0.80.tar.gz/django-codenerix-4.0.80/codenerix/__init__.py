__version__ = "4.0.80"

__authors__ = [
    "Juanmi Taboada",
    "Juan Soler Ruiz",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
    "soleronline@gmail.com",
]

__all__ = ["__version__", "__authors__", "__authors_email__"]
