from typing import Any, List

urlpatterns: List[Any] = []
