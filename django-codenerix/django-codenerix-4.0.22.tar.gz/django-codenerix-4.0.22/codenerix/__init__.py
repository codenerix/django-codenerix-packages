__version__ = "4.0.22"

__authors__ = [
    "Juanmi Taboada",
    "Juan Soler Ruiz",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
    "soleronline@gmail.com",
]
