__version__ = "1.0.6"

__authors__ = [
    'Juan Miguel Taboada Godoy <juanmi@centrologic.com>',
    'Juan Soler Ruiz <soleronline@gmail.com>',
]
