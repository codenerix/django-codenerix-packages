from django.apps import AppConfig


class CodenerixCMSConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'codenerix_cms'
