var module=codenerix_builder(['codenerixInvoicingVendingControllers'],
    {
        'list0': [undefined, get_static('vendings/vending_list.html'), 'codenerixVendingCtrl'],
    }
);
