var module=codenerix_builder(
    [], {
        'list0':[undefined,undefined,'CashDiaryCtrl'],
    }
);

