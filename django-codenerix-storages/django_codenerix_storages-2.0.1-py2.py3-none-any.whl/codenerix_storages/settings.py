CDNX_STORAGE_PERMISSIONS = {
    'operator': [
    ],
}
