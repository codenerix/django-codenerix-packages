var module=codenerix_builder(['codenerixSTORAGESControllers'],
    {
        'list0': [undefined, get_static('codenerix_storages/inventoryout_work.html'), 'CDNXSTORAGESInventoryWorkCtrl'],
        // 'createacta':['/:pk/acta',function(params) { return '/'+ws_entry_point+'/'+params.pk+'/acta'; },'FormEditCtrl'],
    }
);
