var module=codenerix_builder(['codenerixSTORAGESControllers'],
    {
        'list0': [undefined, get_static('codenerix_storages/inventoryin_work.html'), 'CDNXSTORAGESInventoryWorkCtrl'],
    }
);
