__version__ = "2.0.3"

__authors__ = [
    'Juan Miguel Taboada Godoy <juanmi@centrologic.com>',
    'Juan Soler Ruiz <soleronline@gmail.com>',
]
