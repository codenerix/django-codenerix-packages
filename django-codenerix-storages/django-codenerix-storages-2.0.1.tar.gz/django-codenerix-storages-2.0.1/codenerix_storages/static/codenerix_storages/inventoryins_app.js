var module=codenerix_builder(['codenerixSTORAGESControllers'],
    {
        'list0': [undefined, undefined, 'CDNXSTORAGESInventoryWorkCtrl'],
    }
);
