__version__ = "1.0.23"

__authors__ = [
    "Juanmi Taboada <juanmi@juanmitaboada.com>",
]
