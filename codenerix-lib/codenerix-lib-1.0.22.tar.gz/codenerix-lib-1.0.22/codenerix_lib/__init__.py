__version__ = "1.0.22"

__authors__ = [
    "Juanmi Taboada <juanmi@juanmitaboada.com>",
]
