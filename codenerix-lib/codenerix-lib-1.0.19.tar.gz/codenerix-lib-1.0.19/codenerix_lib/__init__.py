__version__ = "1.0.19"

__authors__ = [
    "Juan Miguel Taboada Godoy <juanmi@juanmitaboada.com>",
]
