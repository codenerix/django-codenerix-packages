=============
codenerix-lib
=============

Codenerix LIB is a base module of libraries used by `CODENERIX <http://www.codenerix.com/>`_ you can visit the project at Github `https://github.com/codenerix/django-codenerix`

.. image:: https://github.com/codenerix/django-codenerix/raw/master/codenerix/static/codenerix/img/codenerix.png
    :target: https://www.codenerix.com
    :alt: Try our demo with Codenerix Cloud


**********
Quickstart
**********

1. Install this package::

    For python 2: sudo pip2 install codenerix-lib
    For python 3: sudo pip3 install codenerix-lib

2. Since Codenerix LIB is a library, you only need to import its parts into your project and use them.

*************
Documentation
*************

Coming soon... do you help us?

You can get in touch with us `here <https://codenerix.com/contact/>`_.
