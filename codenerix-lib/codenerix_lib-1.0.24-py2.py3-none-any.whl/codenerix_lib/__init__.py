__version__ = "1.0.24"

__authors__ = [
    "Juanmi Taboada",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
]
