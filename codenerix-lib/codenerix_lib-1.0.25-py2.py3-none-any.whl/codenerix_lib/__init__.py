__version__ = "1.0.25"

__authors__ = [
    "Juanmi Taboada",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
]
