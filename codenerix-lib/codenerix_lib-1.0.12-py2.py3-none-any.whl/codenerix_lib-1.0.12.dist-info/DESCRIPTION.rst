=============
codenerix-lib
=============

Codenerix LIB is a base module of libraries used bys `CODENERIX <http://www.codenerix.com/>`_ 

.. image:: http://www.codenerix.com/wp-content/uploads/2018/05/codenerix.png
    :target: http://www.codenerix.com
    :alt: Try our demo with Codenerix Cloud

**********
Quickstart
**********

1. Install this package::

    For python 2: sudo pip2 install codenerix-lib
    For python 3: sudo pip3 install codenerix-lib

2. Since Codenerix LIB is a library, you only need to import its parts into your project and use them.

*************
Documentation
*************

Coming soon... do you help us? `Codenerix <http://www.codenerix.com/>`_

You can chat with us `here <https://goo.gl/NgpzBh>`_.

*******
Credits
*******

This project has been possible thanks to `Centrologic <http://www.centrologic.com/>`_.


