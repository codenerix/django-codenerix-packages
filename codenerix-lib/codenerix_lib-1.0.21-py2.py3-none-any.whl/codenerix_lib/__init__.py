__version__ = "1.0.21"

__authors__ = [
    "Juanmi Taboada <juanmi@juanmitaboada.com>",
]
