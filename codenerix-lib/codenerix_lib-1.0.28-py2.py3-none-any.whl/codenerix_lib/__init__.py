__version__ = "1.0.28"

__authors__ = [
    "Juanmi Taboada",
]

__authors_email__ = [
    "juanmi@juanmitaboada.com",
]
