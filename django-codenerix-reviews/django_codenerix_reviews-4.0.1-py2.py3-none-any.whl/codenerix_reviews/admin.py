from django.contrib import admin

# Register your models here.

# Automatic added by Codenerix admin.py builder
from codenerix_reviews.models import Reviews

admin.site.register(Reviews)
