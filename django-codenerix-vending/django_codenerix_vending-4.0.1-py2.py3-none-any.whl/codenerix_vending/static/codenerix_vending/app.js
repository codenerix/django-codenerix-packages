// codenerix_dellibs(['codenerixServices', ]);
console.log("app");
var module = codenerix_builder(
	['codenerixVendingsControllers', ],
	{
        'list0': [undefined, undefined, 'codenerixVendingsCtrl'],
	}
);